
import './App.css';
import Statetodos from './Statetodos';
import Reucerprac from './Reucerprac';

function App() {
  return (
<>
<Statetodos/>
<Reucerprac/>
</>
  );
}

export default App;
