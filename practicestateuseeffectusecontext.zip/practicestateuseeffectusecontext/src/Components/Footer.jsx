import React from 'react'

const Footer = () => {
  return (
    <div style={{textAlign:"center"}}>
        <p style={{color:"red"}}>Copyright @ 2024. All Rights Reserved</p>
    </div>
  )
}

export default Footer